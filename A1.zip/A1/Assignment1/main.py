import numpy as np
import matplotlib.pyplot as plt


# Custom implementation of Gradient Descent for Polynomial Regression
def gradient_descent(X, y, theta, learning_rate, num_iterations):
    m = len(y)
    for _ in range(num_iterations):
        error = X.dot(theta) - y
        gradient = X.T.dot(error) / m
        theta = theta - learning_rate * gradient
    return theta


# Custom implementation of Newton's Method for Polynomial Regression
def newtons_method(X, y, theta, num_iterations):
    m = len(y)
    for _ in range(num_iterations):
        error = X.dot(theta) - y
        gradient = X.T.dot(error) / m
        hessian = (X.T.dot(X)) / m
        theta = theta - np.linalg.inv(hessian).dot(gradient)
    return theta


def save_plots_and_results(fig, results_linear, results_quadratic):
    # Save the plot
    fig.savefig("trajectory_plot.png")

    # Save the results to a text file
    with open("results.txt", "w") as file:
        file.write("Results for Linear Regression (3D):\n")
        file.write(f"Estimated Speed (X axis): {results_linear['speed_linear_x']}\n")
        file.write(f"Estimated Speed (Y axis): {results_linear['speed_linear_y']}\n")
        file.write(f"Estimated Speed (Z axis): {results_linear['speed_linear_z']}\n")
        file.write(f"Estimated Speed (3D): {results_linear['speed_linear_3d']}\n")
        file.write(f"Total Residual Error: {results_linear['total_residual_error_linear']}\n\n")

        file.write("Results for Quadratic Regression (Gradient Descent):\n")
        file.write(f"Estimated Acceleration (X axis): {results_quadratic['acceleration_quadratic_x']}\n")
        file.write(f"Estimated Acceleration (Y axis): {results_quadratic['acceleration_quadratic_y']}\n")
        file.write(f"Estimated Acceleration (Z axis): {results_quadratic['acceleration_quadratic_z']}\n")
        file.write(f"Total Residual Error: {results_quadratic['total_residual_error_quadratic']}\n\n")

        file.write(
            f"Predicted Position at 6th Second (Newton's Method): {results_quadratic['predicted_position_at_6th_second_newtons_method']}")


def main():
    # 2.1
    # Given data points
    t = np.array([0, 1, 2, 3, 4, 5])  # time points
    x = np.array([2, 1.08, -0.83, -1.97, -1.31, 0.57])
    y = np.array([0, 1.68, 1.82, 0.28, -1.51, -1.91])
    z = np.array([1, 2.38, 2.49, 2.15, 2.59, 4.32])

    # Degree for linear regression
    degree_linear = 1

    # Create the input matrix with time as the predictor
    X_linear = np.vander(t, degree_linear + 1, increasing=True)

    # Perform linear regression for x, y, and z coordinates
    theta_x_linear = gradient_descent(X_linear, x, np.zeros(degree_linear + 1), learning_rate=0.01, num_iterations=1000)
    theta_y_linear = gradient_descent(X_linear, y, np.zeros(degree_linear + 1), learning_rate=0.01, num_iterations=1000)
    theta_z_linear = gradient_descent(X_linear, z, np.zeros(degree_linear + 1), learning_rate=0.01, num_iterations=1000)

    # 2.2 & 2.3
    # Degree for quadratic regression
    degree_quadratic = 2

    # Create the input matrix with time as the predictor
    X_quadratic = np.vander(t, degree_quadratic + 1, increasing=True)

    # Initialize parameters for both methods
    theta_x_gradient = np.zeros(degree_quadratic + 1)
    theta_y_gradient = np.zeros(degree_quadratic + 1)
    theta_z_gradient = np.zeros(degree_quadratic + 1)

    theta_x_newton = np.zeros(degree_quadratic + 1)
    theta_y_newton = np.zeros(degree_quadratic + 1)
    theta_z_newton = np.zeros(degree_quadratic + 1)

    # Perform quadratic regression for x, y, and z coordinates with Gradient Descent
    theta_x_gradient = gradient_descent(X_quadratic, x, theta_x_gradient, learning_rate=0.01, num_iterations=1000)
    theta_y_gradient = gradient_descent(X_quadratic, y, theta_y_gradient, learning_rate=0.01, num_iterations=1000)
    theta_z_gradient = gradient_descent(X_quadratic, z, theta_z_gradient, learning_rate=0.01, num_iterations=1000)

    # Perform quadratic regression for x, y, and z coordinates with Newton's method
    theta_x_newton = newtons_method(X_quadratic, x, theta_x_newton, num_iterations=10)
    theta_y_newton = newtons_method(X_quadratic, y, theta_y_newton, num_iterations=10)
    theta_z_newton = newtons_method(X_quadratic, z, theta_z_newton, num_iterations=10)

    # Predict the trajectories using the fitted models
    t_pred = np.linspace(0, 6, 100)  # Extend time range to predict next second
    X_pred_linear = np.vander(t_pred, degree_linear + 1, increasing=True)
    X_pred_quadratic = np.vander(t_pred, degree_quadratic + 1, increasing=True)

    x_pred_gradient = X_pred_quadratic.dot(theta_x_gradient)
    y_pred_gradient = X_pred_quadratic.dot(theta_y_gradient)
    z_pred_gradient = X_pred_quadratic.dot(theta_z_gradient)

    x_pred_newton = X_pred_quadratic.dot(theta_x_newton)
    y_pred_newton = X_pred_quadratic.dot(theta_y_newton)
    z_pred_newton = X_pred_quadratic.dot(theta_z_newton)

    # Calculate overall speed in 3D space
    speed_linear_x = theta_x_linear[1]
    speed_linear_y = theta_y_linear[1]
    speed_linear_z = theta_z_linear[1]

    speed_linear_3d = np.sqrt(speed_linear_x ** 2 + speed_linear_y ** 2 + speed_linear_z ** 2)

    # Predict the trajectories using the fitted models
    X_pred_linear = np.vander(t, degree_linear + 1, increasing=True)
    x_pred_linear = X_pred_linear.dot(theta_x_linear)
    y_pred_linear = X_pred_linear.dot(theta_y_linear)
    z_pred_linear = X_pred_linear.dot(theta_z_linear)

    # Calculate the total residual error in 3D space
    total_residual_error_linear = np.sum(
        (np.vstack((x_pred_linear, y_pred_linear, z_pred_linear)).T - np.vstack((x, y, z)).T) ** 2)

    # Print the results for linear regression
    print("\nResults for Linear Regression (3D):")
    print(f"Estimated Speed (X axis): {speed_linear_x}")
    print(f"Estimated Speed (Y axis): {speed_linear_y}")
    print(f"Estimated Speed (Z axis): {speed_linear_z}")
    print(f"Estimated Speed (3D): {speed_linear_3d}")
    print(f"Total Residual Error: {total_residual_error_linear}")

    # Store the linear regression results in a dictionary
    results_linear = {
        'speed_linear_x': speed_linear_x,
        'speed_linear_y': speed_linear_y,
        'speed_linear_z': speed_linear_z,
        'speed_linear_3d': speed_linear_3d,
        'total_residual_error_linear': total_residual_error_linear
    }

    # Predict the trajectories using the fitted models
    X_pred_quadratic = np.vander(t, degree_quadratic + 1, increasing=True)
    x_pred_quadratic = X_pred_quadratic.dot(theta_x_gradient)
    y_pred_quadratic = X_pred_quadratic.dot(theta_y_gradient)
    z_pred_quadratic = X_pred_quadratic.dot(theta_z_gradient)

    # Calculate acceleration and residual error for quadratic regression
    acceleration_quadratic_x = 2 * theta_x_gradient[2]
    acceleration_quadratic_y = 2 * theta_y_gradient[2]
    acceleration_quadratic_z = 2 * theta_z_gradient[2]

    total_residual_error_quadratic = np.sum(
        (np.vstack((x_pred_quadratic, y_pred_quadratic, z_pred_quadratic)).T - np.vstack((x, y, z)).T) ** 2)

    # Print the results for quadratic regression
    print("\nResults for Quadratic Regression (Gradient Descent):")
    print(f"Estimated Acceleration (X axis): {acceleration_quadratic_x}")
    print(f"Estimated Acceleration (Y axis): {acceleration_quadratic_y}")
    print(f"Estimated Acceleration (Z axis): {acceleration_quadratic_z}")
    print(f"Total Residual Error: {total_residual_error_quadratic}")

    # Print the predicted position in the next second
    predicted_position = np.array([x_pred_newton[-1], y_pred_newton[-1], z_pred_newton[-1]])
    print(f"Predicted Position at 6th Second (Newton's Method): {predicted_position}")

    # Store the quadratic regression results in a dictionary
    results_quadratic = {
        'acceleration_quadratic_x': acceleration_quadratic_x,
        'acceleration_quadratic_y': acceleration_quadratic_y,
        'acceleration_quadratic_z': acceleration_quadratic_z,
        'total_residual_error_quadratic': total_residual_error_quadratic,
        'predicted_position_at_6th_second_newtons_method': predicted_position
    }

    # Create the initial figure
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')

    # Plot the actual trajectory
    ax.plot(x, y, z, marker='o', linestyle='-', color='blue', label='Actual Trajectory')

    # Plot the fitting trajectories
    ax.plot(x_pred_linear, y_pred_linear, z_pred_linear,
            label='Fitting Trajectory (Constant Velocity)', color='orange')
    ax.plot(x_pred_gradient, y_pred_gradient, z_pred_gradient,
            label='Fitting Trajectory (Constant Acceleration)', color='red')
    ax.plot(x_pred_newton, y_pred_newton, z_pred_newton,
            label='Fitting Trajectory (Newton\'s Method)', color='green')
    ax.scatter(predicted_position[0], predicted_position[1], predicted_position[2],
               marker='x', color='green', s=100, label='Predicted Position at 6th Second')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.legend(loc='upper right')

    # Save the figure as a PNG image
    fig.savefig('./trajectory_plot.png')
    plt.show()

    # Save the plots and results
    save_plots_and_results(fig, results_linear, results_quadratic)


if __name__ == "__main__":
    main()
