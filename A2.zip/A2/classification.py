"""
This demo shows how to visualize the designed features. Currently, only 2D feature space visualization is supported.
I use the same data for A2 as my input.
Each .xyz file is initialized as one urban object, from where a feature vector is computed.
6 features are defined to describe an urban object.
Required libraries: numpy, scipy, scikit learn, matplotlib, tqdm 
"""

import math
import matplotlib.pyplot as plt
import numpy as np
from sklearn.neighbors import KDTree
from sklearn import svm
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from scipy.spatial import ConvexHull
from tqdm import tqdm
from os.path import exists, join
from os import listdir


class urban_object:
    """
    Define an urban object
    """

    def __init__(self, filenm):
        """
        Initialize the object
        """
        # obtain the cloud name
        self.cloud_name = filenm.split('/\\')[-1][-7:-4]

        # obtain the cloud ID
        self.cloud_ID = int(self.cloud_name)

        # obtain the label
        self.label = math.floor(1.0 * self.cloud_ID / 100)

        # obtain the points
        self.points = read_xyz(filenm)

        # initialize the feature vector
        self.feature = []

    def compute_features(self):
        """
        Compute the features, here we provide two example features. You're encouraged to design your own features
        12 Features: height, root_density, area, shape_index, sum_eigenvalues,
                linearity, planarity, sphericity, change_of_curvature, verticality, abs_moment, vertical_moment
        """
        # calculate the height
        height = np.amax(self.points[:, 2])
        self.feature.append(height)

        # get the root point and top point
        root = self.points[[np.argmin(self.points[:, 2])]]
        top = self.points[[np.argmax(self.points[:, 2])]]

        # construct the 2D and 3D kd tree
        kd_tree_2d = KDTree(self.points[:, :2], leaf_size=5)
        kd_tree_3d = KDTree(self.points, leaf_size=5)

        # compute the root point planar density
        radius_root = 0.2
        count = kd_tree_2d.query_radius(root[:, :2], r=radius_root, count_only=True)
        root_density = 1.0 * count[0] / len(self.points)
        self.feature.append(root_density)

        # compute the 2D footprint and calculate its area
        hull_2d = ConvexHull(self.points[:, :2])
        hull_area = hull_2d.volume
        self.feature.append(hull_area)

        # get the hull shape index
        hull_perimeter = hull_2d.area
        shape_index = 1.0 * hull_area / hull_perimeter
        self.feature.append(shape_index)

        # obtain the point cluster near the top area
        k_top = max(int(len(self.points) * 0.005), 100)
        idx = kd_tree_3d.query(top, k=k_top, return_distance=False)
        idx = np.squeeze(idx, axis=0)
        neighbours = self.points[idx, :]

        # Calculate the covariance matrix for the top cluster
        centroid_top = np.mean(neighbours, axis=0)
        centered_neighbours = neighbours - centroid_top
        cov_matrix_top = np.cov(centered_neighbours.T)

        # obtain the covariance matrix of the top points
        cov = np.cov(cov_matrix_top.T)
        w, v = np.linalg.eig(cov)
        w.sort()

        # Compute the sum of eigenvalues
        sum_eigenvalues = np.sum(w)
        self.feature.append(sum_eigenvalues)

        # calculate the linearity, planarity and sphericity  w[0]: minimal eigenvector w[2]: maximal eigenvector
        linearity = (w[2] - w[1]) / (w[2] + 1e-5)
        planarity = (w[1] - w[0]) / (w[2] + 1e-5)
        sphericity = w[0] / (w[2] + 1e-5)
        self.feature += [linearity, planarity, sphericity]

        # Compute Change of Curvature
        change_of_curvature = w[0] / sum_eigenvalues
        self.feature.append(change_of_curvature)

        # Compute Verticality (assuming the Z-axis is up)
        verticality = 1 - abs(np.dot(v[:, 2], np.array([0, 0, 1])))
        self.feature.append(verticality)

        # Compute Absolute Moment (assuming k=2)
        abs_moment = np.mean(np.linalg.norm(centered_neighbours, axis=1) ** 2)
        self.feature.append(abs_moment)

        # Compute Vertical Moment (assuming k=2)
        vertical_moment = np.mean(centered_neighbours[:, 2] ** 2)
        self.feature.append(vertical_moment)


def read_xyz(filenm):
    """
    Reading points
        filenm: the file name
    """
    points = []
    with open(filenm, 'r') as f_input:
        for line in f_input:
            p = line.split()
            p = [float(i) for i in p]
            points.append(p)
    points = np.array(points).astype(np.float32)
    return points


def feature_preparation(data_path):
    """
    Prepare features of the input point cloud objects
        data_path: the path to read data
    """
    # check if the current data file exist
    data_file = 'data.txt'
    if exists(data_file):
        return

    # obtain the files in the folder
    files = sorted(listdir(data_path))

    # initialize the data
    input_data = []

    # retrieve each data object and obtain the feature vector
    for file_i in tqdm(files, total=len(files)):
        # obtain the file name
        file_name = join(data_path, file_i)

        # read data
        i_object = urban_object(filenm=file_name)

        # calculate features
        i_object.compute_features()

        # add the data to the list
        i_data = [i_object.cloud_ID, i_object.label] + i_object.feature
        input_data += [i_data]

    # transform the output data
    outputs = np.array(input_data).astype(np.float32)

    # write the output to a local file
    data_header_4 = 'ID,label,height,root_density,area,vertical_moment'
    data_header = 'ID,label,height,root_density,area,shape_index,sum_eigenvalues,linearity,planarity,sphericity,change_of_curvature,verticality,abs_moment,vertical_moment'
    np.savetxt(data_file, outputs, fmt='%10.5f', delimiter=',', newline='\n', header=data_header)


def data_loading(data_file='data.txt'):
    """
    Read the data with features from the data file
        data_file: the local file to read data with features and labels
    """
    # load data
    data = np.loadtxt(data_file, dtype=np.float32, delimiter=',', comments='#')

    # extract object ID, feature X and label Y
    ID = data[:, 0].astype(np.int32)
    y = data[:, 1].astype(np.int32)
    X = data[:, 2:].astype(np.float32)

    return ID, X, y


def feature_visualization(X):
    """
    Visualize the features
        X: input features. This assumes classes are stored in a sequential manner
    """
    # initialize a plot
    fig = plt.figure()
    ax = fig.add_subplot()
    plt.title("feature subset visualization of 5 classes", fontsize="small")

    # define the labels and corresponding colors
    colors = ['firebrick', 'grey', 'darkorange', 'dodgerblue', 'olivedrab']
    labels = ['building', 'car', 'fence', 'pole', 'tree']

    # plot the data with first two features
    for i in range(5):
        ax.scatter(X[100 * i:100 * (i + 1), 0], X[100 * i:100 * (i + 1), 1], marker="o", c=colors[i], edgecolor="k",
                   label=labels[i])

    # show the figure with labels
    """
    Replace the axis labels with your own feature names
    """
    ax.set_xlabel('x1:root density')
    ax.set_ylabel('x2:area')
    ax.legend()
    plt.show()


# Function to calculate mean per-class accuracy
def mean_per_class_accuracy(y_true, y_pred, n_classes):
    """
    Compute the mean per-class accuracy.

    Parameters:
    - y_true: Array of true labels.
    - y_pred: Array of predicted labels.
    - n_classes: The number of classes.

    Returns:
    - Mean per-class accuracy.
    """
    cm = confusion_matrix(y_true, y_pred)
    per_class_acc = cm.diagonal() / cm.sum(axis=1)
    mean_per_class_acc = np.nanmean(per_class_acc)
    return mean_per_class_acc


def SVM_classification(X, y, test_size, C, kernel, gamma, degree):
    """
    Conduct SVM classification
        X: features
        y: labels
    """
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size)
    clf = svm.SVC(C=C, kernel=kernel, gamma=gamma, degree=degree)
    clf.fit(X_train, y_train)
    y_preds = clf.predict(X_test)

    acc = accuracy_score(y_test, y_preds)
    print("SVM accuracy: %5.2f" % acc)
    conf = confusion_matrix(y_test, y_preds)
    per_class_acc = conf.diagonal() / conf.sum(axis=1)
    mean_acc = np.nanmean(per_class_acc)
    print(f"Mean per-class accuracy: {mean_acc:.2f}")
    print("confusion matrix")
    print(conf)


def RF_classification(X, y, test_size, n_estimators, max_depth, min_samples_split, min_samples_leaf, random_state):
    """
    Conduct RF classification
        X: features
        y: labels
    """
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size)
    clf = RandomForestClassifier(n_estimators=n_estimators, max_depth=max_depth, min_samples_split=min_samples_split,
                                 min_samples_leaf=min_samples_leaf, random_state=random_state)
    clf.fit(X_train, y_train)
    y_preds = clf.predict(X_test)

    acc = accuracy_score(y_test, y_preds)
    print("Random Forest accuracy: %5.2f" % acc)
    conf = confusion_matrix(y_test, y_preds)
    per_class_acc = conf.diagonal() / conf.sum(axis=1)
    mean_acc = np.nanmean(per_class_acc)
    print(f"Mean per-class accuracy: {mean_acc:.2f}")
    print("confusion matrix")
    print(conf)


def svm_grid_search(X, y, C_values, kernel_values, gamma_values, degree_values, cv=5):
    """
    Perform a grid search for optimal SVM parameters including the 'degree' parameter for the polynomial kernel.

    Parameters:
    - X: Input features.
    - y: Labels.
    - C_values: List of C values to try.
    - kernel_values: List of kernels to try.
    - gamma_values: List of gamma values to try.
    - degree_values: List of degree values to try for the polynomial kernel.
    - cv: Number of cross-validation folds.

    Returns:
    - A dictionary with the best found parameter values and the corresponding score.
    """
    best_score = 0
    best_params = {'C': None, 'kernel': None, 'gamma': None, 'degree': None}

    for C in C_values:
        for kernel in kernel_values:
            for gamma in gamma_values:
                for degree in degree_values:
                    # Train and evaluate the SVM with the current set of parameters
                    svm_clf = svm.SVC(C=C, kernel=kernel, gamma=gamma, degree=degree)
                    scores = cross_val_score(svm_clf, X, y, cv=cv)
                    mean_score = np.mean(scores)
                    print("mean_score:", mean_score)

                    # Update best_score and best_params if the current model is better
                    if mean_score > best_score:
                        best_score = mean_score
                        best_params = {'C': C, 'kernel': kernel, 'gamma': gamma, 'degree': degree}

    print(f"Best Score of SVM Classifier: {best_score}")
    print(f"Best Parameters of SVM Classifier: {best_params}")
    return best_params


def rf_grid_search(X, y, n_estimators_values, max_depth_values, min_samples_split_values, min_samples_leaf_values,
                   cv=5):
    """
    Perform a grid search to find the best Random Forest parameters.

    Parameters:
    - X: Input features.
    - y: Target variable.
    - n_estimators_values: List of n_estimators values to try.
    - max_depth_values: List of max_depth values to try.
    - min_samples_split_values: List of min_samples_split values to try.
    - min_samples_leaf_values: List of min_samples_leaf values to try.
    - cv: Number of cross-validation folds.

    Returns:
    - A dictionary with the best found parameter values and the corresponding score.
    """
    best_score = 0
    best_params = {
        'n_estimators': None,
        'max_depth': None,
        'min_samples_split': None,
        'min_samples_leaf': None
    }

    for n_estimators in n_estimators_values:
        for max_depth in max_depth_values:
            for min_samples_split in min_samples_split_values:
                for min_samples_leaf in min_samples_leaf_values:
                    rf = RandomForestClassifier(
                        n_estimators=n_estimators,
                        max_depth=max_depth,
                        min_samples_split=min_samples_split,
                        min_samples_leaf=min_samples_leaf
                    )
                    scores = cross_val_score(rf, X, y, cv=cv)
                    mean_score = np.mean(scores)
                    print("mean_score:", mean_score)

                    if mean_score > best_score:
                        best_score = mean_score
                        best_params = {
                            'n_estimators': n_estimators,
                            'max_depth': max_depth,
                            'min_samples_split': min_samples_split,
                            'min_samples_leaf': min_samples_leaf
                        }

    print(f"Best Score of RF Classifier: {best_score}")
    print(f"Best Parameters of RF Classifier: {best_params}")
    return best_params


def plot_learning_curve(X, y, model, check_interval=0.02, iterations=5):
    """
    Plot the learning curve of a model given training data.

    Parameters:
    - X: Feature matrix.
    - y: Target vector.
    - model: The machine learning model to train.
    - check_interval: The interval to check learning curve points.
    - iterations: The number of iterations to average over for each point.

    This function plots the learning curve, showing the apparent error rate
    (training error) and true error rate (validation error) as the training
    set size increases.
    """
    model_name = "Model"  # Default title in case model name can't be determined
    if isinstance(model, svm.SVC):
        model_name = "SVM"
    elif isinstance(model, RandomForestClassifier):
        model_name = "Random Forest"

    train_sizes = []
    train_errors = []
    validation_errors = []

    # Adjust the range to include the end point
    for i in range(1, int(1 / check_interval)):
        train_size_ratio = i * check_interval
        print(train_size_ratio)
        train_errors_i = []
        validation_errors_i = []

        for _ in range(iterations):
            # Adjust for correct train_size use in train_test_split
            X_train, X_val, y_train, y_val = train_test_split(X, y, train_size=train_size_ratio, random_state=42)

            model.fit(X_train, y_train)
            y_train_pred = model.predict(X_train)
            y_val_pred = model.predict(X_val)

            # Calculate errors
            train_error = 1 - accuracy_score(y_train, y_train_pred)
            validation_error = 1 - accuracy_score(y_val, y_val_pred)

            train_errors_i.append(train_error)
            validation_errors_i.append(validation_error)

        # Average errors over the iterations
        train_errors.append(np.mean(train_errors_i))
        validation_errors.append(np.mean(validation_errors_i))
        train_sizes.append(len(X_train))

    # Plotting
    plt.figure(figsize=(10, 6))
    plt.plot(train_sizes, train_errors, label='Apparent Error Rate (Training error)', marker='o')
    plt.plot(train_sizes, validation_errors, label='True Error Rate (Validation error)', marker='x')
    plt.xticks(np.arange(min(train_sizes), max(train_sizes) + 1, 50))
    plt.xlabel('Training set size')
    plt.ylabel('Classification error')
    plt.title(f'{model_name} Learning Curve')
    plt.legend()
    plt.grid(False)
    plt.show()


if __name__ == '__main__':
    # specify the data folder
    """"Here you need to specify your own path"""
    path = './pointclouds-500./pointclouds-500'

    # conduct feature preparation
    print('Start preparing features')
    feature_preparation(data_path=path)

    # load the data
    print('Start loading data from the local file')
    ID, X, y = data_loading()

    # visualize features
    # print('Visualize the features')
    # feature_visualization(X=X)

    # SVM Hyperparameter Tuning
    C_values = [0.1, 1, 10]
    kernel_values = ['linear', 'rbf', 'poly']  # Added 'poly' to utilize 'degree'
    gamma_values = ['scale', 'auto']
    degree_values = [2, 3, 4]  # Degrees for the polynomial kernel
    best_svm_params = svm_grid_search(X, y, C_values, kernel_values, gamma_values, degree_values)
    print("best_svm_params: ", best_svm_params)

    # RF Hyperparameter Tuning
    n_estimators_values = [10, 50, 100]
    max_depth_values = [None, 10, 20, 30]
    min_samples_split_values = [2, 5, 10]
    min_samples_leaf_values = [1, 2, 4]
    best_rf_params = rf_grid_search(X, y, n_estimators_values, max_depth_values, min_samples_split_values,
                                    min_samples_leaf_values)
    print("best_rf_params: ", best_rf_params)

    # SVM Learning Curve Plotting
    SVM_model = svm.SVC(C=best_svm_params['C'],
                        kernel=best_svm_params['kernel'],
                        gamma=best_svm_params['gamma'],
                        degree=best_svm_params['degree'])
    plot_learning_curve(X, y, SVM_model)

    # RF Learning Curve Plotting
    RF_model = RandomForestClassifier(n_estimators=best_rf_params['n_estimators'],
                                      max_depth=best_rf_params['max_depth'],
                                      min_samples_split=best_rf_params['min_samples_split'],
                                      min_samples_leaf=best_rf_params['min_samples_leaf'],
                                      random_state=None)
    plot_learning_curve(X, y, RF_model)

    # SVM classification
    print('Start SVM classification')
    SVM_classification(X, y, test_size=0.4, C=best_svm_params['C'],
                       kernel=best_svm_params['kernel'],
                       gamma=best_svm_params['gamma'],
                       degree=best_svm_params['degree'])

    # RF classification
    print('Start RF classification')
    RF_classification(X, y, n_estimators=best_rf_params['n_estimators'],
                      max_depth=best_rf_params['max_depth'],
                      min_samples_split=best_rf_params['min_samples_split'],
                      min_samples_leaf=best_rf_params['min_samples_leaf'],
                      random_state=None, test_size=0.4)
